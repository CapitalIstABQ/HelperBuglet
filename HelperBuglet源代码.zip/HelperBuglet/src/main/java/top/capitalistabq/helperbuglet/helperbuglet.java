package top.capitalistabq.helperbuglet;

import cn.nukkit.Player;
import cn.nukkit.command.Command;
import cn.nukkit.command.CommandSender;
import cn.nukkit.plugin.PluginBase;
import cn.nukkit.utils.Config;

public class HelperBuglet
extends PluginBase {
    Config c;

    public void onEnable() {
        this.saveDefaultConfig();
        this.c = this.getConfig();
    }

    public boolean onCommand(CommandSender sender, Command cmd, String commandLabel, String[] args) {
        if (!(sender instanceof Player)) {
            return true;
        }
        if (cmd.getName().equalsIgnoreCase("hlaba")) {
            for (Player p : this.getServer().getOnlinePlayers().values()) {
                if (!p.hasPermission("hlaba.chat")) continue;
                p.sendMessage(this.c.getString("Messages").replace((CharSequence)"Â§", (CharSequence)"§").replace((CharSequence)"{name}", (CharSequence)sender.getName()).replace((CharSequence)"{msg}", (CharSequence)String.join((CharSequence)" ", (CharSequence[])args)));
            }
            return true;
        }
        return true;
    }
}